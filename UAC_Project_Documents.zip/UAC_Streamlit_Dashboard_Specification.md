# Streamlit Dashboard Specification — HHS UAC Care-Load Analytics

## Purpose
Provide government stakeholders with a live, transparent view of UAC care load, operational flows, data quality, and short-horizon forecast signals.

## Recommended layout
### Sidebar filters
- Date range
- Metric selector: HHS active, CBP intake, CBP active, transfers out, HHS discharged, net pressure
- Rolling window: 7 or 14 days
- Alert threshold for day-over-day change

### KPI row
- Latest HHS active care load
- 7-day average and direction
- Latest net pressure
- Latest intake and discharge flows
- Missing-date count
- Last reported date

### Main tabs
1. **Overview:** HHS active trend, rolling averages, and alert banner.
2. **Flows:** intake, transfers out, discharges, and net pressure.
3. **Seasonality:** monthly and weekday patterns.
4. **Forecasting:** naive, moving-average, ARIMA/Holt-Winters, and machine-learning forecasts with holdout metrics.
5. **Data Quality:** missing dates, nulls, duplicates, extreme changes, and source refresh status.

## Suggested visualizations
- Interactive line chart for HHS active care load.
- Dual-axis or faceted flow chart for intake and discharges.
- Net-pressure chart with zero reference line and alert bands.
- Calendar heatmap for daily HHS active load.
- Boxplots by month and weekday.
- Forecast fan chart with prediction intervals where supported.

## Live analytics behavior
- Re-read the CSV or connected data source on refresh.
- Cache raw data briefly, but allow a manual refresh button.
- Preserve raw values and show explicitly when dates are missing.
- Do not silently impute missing dates in the executive KPI layer.
- Display a “last updated” timestamp and data-quality status.

## Alert logic
- Missing reporting date: warning.
- Absolute day-over-day change above configurable percentile: review flag.
- Sustained positive net pressure for 3+ observations: capacity-pressure alert.
- Latest value outside a rolling historical band: anomaly flag.

## Implementation notes
- Use `st.cache_data` for loading and cleaning.
- Use Plotly for hoverable charts.
- Use tabs and expandable methodology notes.
- Add CSV download of the filtered view and forecast table.
- Include a disclaimer that forecasts are decision support and require operational validation.

## Acceptance criteria
- Stakeholders can identify current load in under 10 seconds.
- Every KPI shows its date and data-quality status.
- Users can inspect the exact observations behind alerts.
- Forecast metrics are shown beside forecasts.
- Missing dates and any imputation are visible, not hidden.
